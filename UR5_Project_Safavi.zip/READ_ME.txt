%%%%%% M.Amin Safavi %%%%%%%
%%%%%%  UR5 Project  %%%%%%%


Instrustions to Run the Program:

1)Run the following Files:
	--initial.m
	--Project_UR5.mdl
	--UR5.ttt
2) Go to Connection Vrep and open the following Files:
	--ConnectToVREP.m
	--Command.m
3) Configure the Trajectory
4) Run  initial.m
5) Start the simulation in VREP
6) Run ConnectToVREP.m
 



Any Quenstions Contact:
safavi.m.amin@gmail.com